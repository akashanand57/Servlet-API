package com.jsp.servlet_simple_crud_operation.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.jsp.servlet_simple_crud_operation.connection.ProductConnection;
import com.jsp.servlet_simple_crud_operation.dto.Product;

public class ProductDao {
	
	Connection connection=ProductConnection.getProductConnection();
	
	private final String INSERTPRODUCTQUERY= "insert into product(id, name, price, mfd, expd) values(?,?,?,?,?)";
	
	public Product saveProductDao(Product product) {
		
		try {
			PreparedStatement ps=connection.prepareStatement(INSERTPRODUCTQUERY);
			ps.setInt(1, product.getId());
			ps.setString(2, product.getName());
			ps.setDouble(3, product.getPrice());
			ps.setObject(4, product.getMfd());
			ps.setObject(5, product.getExpd());
			ps.execute();
			return product;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
	}
}
